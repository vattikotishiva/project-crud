from django.apps import AppConfig


class QuoraConfig(AppConfig):
    name = 'quora'
